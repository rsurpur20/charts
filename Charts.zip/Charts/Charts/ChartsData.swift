//
//  ChartsData.swift
//  Charts
//
//  Created by Roshni Surpur on 3/16/21.
//

import SwiftUICharts

struct Data {
    static let title = "Sales"
    static let legend = "Mentoring"
    static let valueSpecifier = "USD"
    
    static let rateValue = 57
    
    static let data0 = [8.0, 32.0, 11.0, 23.0, 40.0, 28.0]
    static let data1 = [90.0, 99.0, 78.0, 80.0, 60.0, 98.0]
    static let data2 = [34.0, 99.0, 78.0, 80.0, 60.0, 98.0]
    
    static let line0 = (data0, GradientColors.green)
    static let line1 = (data1, GradientColors.purple)
    static let line2 = (data2, GradientColors.orngPink)
    
    static let multiline = [line0, line1, line2]
    
    static let barData = ChartData(values: [(" '18 Q4 - 63150", 63150), (" '19 Q1 - 50900", 50900), (" '19 Q2 - 77550", 77550), (" '19 Q3 - 79600", 79600), (" '19 Q4 - 92550", 92550) ])
    
    static let pieData = [8.0, 23.0, 88.0, 32.0]
    
    
}
