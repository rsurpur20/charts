//
//  ChartStyles.swift
//  Charts
//
//  Created by Roshni Surpur on 3/16/21.
//

import SwiftUI
import SwiftUICharts

struct Style {
    static let mentoring = ChartStyle(backgroundColor: Color.black.opacity(0.05), accentColor: .yellow, gradientColor: GradientColor(start:Color.green.opacity(0.5), end: .green), textColor: .black, legendTextColor: .gray, dropShadowColor: .black)
    
}

