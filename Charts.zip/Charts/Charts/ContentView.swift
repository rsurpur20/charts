//
//  ContentView.swift
//  Charts
//
//  Created by Roshni Surpur on 3/16/21.
//

import SwiftUI
import SwiftUICharts
struct ContentView: View {
    var body: some View {
        ScrollView{
            Text("Sales").font(.title)
            Text("$838.90").font(.largeTitle)
            
            BarChartView(data: ChartData(points: [8,23,54,32,12]), title: "Weekly Sales", style: Style.mentoring, form: ChartForm.medium)
                
                .padding(.vertical,20)
            Text("Highlights").font(.title).frame(maxWidth: .infinity, alignment: .center)
        VStack{
            HStack{
//                BarChartView(data: ChartData(points: [8,23,54,32,12]), title: "Title", style: Style.mentoring, form: ChartForm.medium)
//
//            BarChartView(data: ChartData(points: [8,23,32,12,37,7]), title: "Title", style: Style.mentoring, form: ChartForm.medium)
            }
//        }//.edgesIgnoringSafeArea(.all)
//            HStack{
//            MultiLineChartView(data: Data.multiline, title: "Sales", legend: Data.legend, style: Style.mentoring, rateValue: Data.rateValue, dropShadow: true, valueSpecifier: Data.valueSpecifier)
//            MultiLineChartView(data: [([8,32,11,23,40,28], GradientColors.green), ([90,99,78,111,70,60,77], GradientColors.purple), ([34,56,72,38,43,100,50], GradientColors.orngPink)], title: "Title")
//            LineView(data: [8,23,54,32,12,37,7,23,43], title: "Line chart") // legend is optional, use optional .padding()
//            HStack {
                PieChartView(data: [8,23,54,32], title: "ROI", legend: "Return on Investment", style: Style.mentoring, form: ChartForm.large) // legend is optional
                
                
//            }
            .padding(.vertical,20)
            PieChartView(data: [23,64,2], title: "WeeklySpending", legend: "Majority of Spending on xyz", style: Style.mentoring, form: ChartForm.large) // legend is optional

//            }
        }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


//import SwiftUI
//import CoreData
//
//struct ContentView: View {
//    @Environment(\.managedObjectContext) private var viewContext
//
//    @FetchRequest(
//        sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)],
//        animation: .default)
//    private var items: FetchedResults<Item>
//
//    var body: some View {
//        List {
//            ForEach(items) { item in
//                Text("Item at \(item.timestamp!, formatter: itemFormatter)")
//            }
//            .onDelete(perform: deleteItems)
//        }
//        .toolbar {
//            #if os(iOS)
//            EditButton()
//            #endif
//
//            Button(action: addItem) {
//                Label("Add Item", systemImage: "plus")
//            }
//        }
//    }
//
//    private func addItem() {
//        withAnimation {
//            let newItem = Item(context: viewContext)
//            newItem.timestamp = Date()
//
//            do {
//                try viewContext.save()
//            } catch {
//                // Replace this implementation with code to handle the error appropriately.
//                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
//                let nsError = error as NSError
//                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
//            }
//        }
//    }
//
//    private func deleteItems(offsets: IndexSet) {
//        withAnimation {
//            offsets.map { items[$0] }.forEach(viewContext.delete)
//
//            do {
//                try viewContext.save()
//            } catch {
//                // Replace this implementation with code to handle the error appropriately.
//                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
//                let nsError = error as NSError
//                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
//            }
//        }
//    }
//}
//
//private let itemFormatter: DateFormatter = {
//    let formatter = DateFormatter()
//    formatter.dateStyle = .short
//    formatter.timeStyle = .medium
//    return formatter
//}()
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
//    }
//}
